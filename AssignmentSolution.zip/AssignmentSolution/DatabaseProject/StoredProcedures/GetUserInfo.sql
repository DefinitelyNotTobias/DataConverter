﻿-- GetUserInfo.sql

CREATE PROCEDURE GetUserInfo
	@UserID UNIQUEIDENTIFIER
AS
BEGIN
	SELECT Username, Email, [Address]
	FROM Usernames u
	LEFT JOIN Emails e ON u.UserID = e.UserID
	LEFT JOIN Addresses a ON u.UserID = a.UserID
	WHERE u.UserID = @UserID;
END;
