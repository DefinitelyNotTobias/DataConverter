﻿-- GetUsersStartingWith.sql

CREATE PROCEDURE GetUsersStartingWith
	@StartLetters VARCHAR(254)
AS
BEGIN
	DECLARE @SearchTerm VARCHAR(255) = @StartLetters + '%';

	SELECT Username
	FROM Usernames
	WHERE Username LIKE @SearchTerm;
END;
