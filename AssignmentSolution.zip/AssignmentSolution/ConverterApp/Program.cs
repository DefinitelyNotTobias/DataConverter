﻿using System;
using System.Data;
using System.Data.SqlClient;
using ConverterApp.Converters;
using ConverterApp.Models;

namespace ConverterApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string conString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=UserManagementDB;user id=sa;password=yzm95txs";

            SqlConnection con = new SqlConnection(conString);

            try
            {
                con.Open();

                Console.WriteLine("Enter the procedure name and parameter (For instance, GetUserInfo 22222222-2222-2222-2222-222222222222)");
                string? command = Console.ReadLine();

                ExecuteProcedure(con, command);
            }
            catch (SqlException ex)
            {
                Console.WriteLine("SQL Exception: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        static void ExecuteProcedure(SqlConnection con, string? command)
        {
            if (string.IsNullOrWhiteSpace(command))
            {
                Console.WriteLine("Invalid command");
                return;
            }

            string[] commandParts = command.Split(' ');
            if (commandParts.Length < 1)
            {
                Console.WriteLine("Please provide a procedure name");
                return;
            }

            string procedureName = commandParts[0];
            string? parameterValue = commandParts.Length > 1 ? commandParts[1] : null;

            switch (procedureName)
            {
                case "GetUserInfo":
                    ExecuteGetUserInfo(con, parameterValue);
                    break;
                case "GetUsersStartingWith":
                    ExecuteGetUsersStaringWith(con, parameterValue);
                    break;
                default:
                    Console.WriteLine($"Procedure '{procedureName}' was not recognized");
                    break;
            }
        }

        static void ExecuteGetUserInfo(SqlConnection con, string? userID)
        {
            SqlCommand cmd = new SqlCommand("GetUserInfo", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", userID);

            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            reader.Close();
            cmd.Dispose();

            UserDetails? userDetails = DataConverter.ConvertToModel(dataTable, row => new UserDetails(
                    row["Username"].ToString(),
                    row["Email"].ToString(),
                    row["Address"].ToString()
                ));

            if (userDetails != null)
            {
                Console.WriteLine($"Username: {userDetails.Username}");
                Console.WriteLine($"Email: {userDetails.Email}");
                Console.WriteLine($"Address: {userDetails.Address}");
            }
            else
            {
                Console.WriteLine("No user details found");
            }
        }

        static void ExecuteGetUsersStaringWith(SqlConnection con, string? startingLetters)
        {
            SqlCommand cmd = new SqlCommand("GetUsersStartingWith", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StartLetters", startingLetters);

            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            reader.Close();
            cmd.Dispose();

            List<string> usernames = DataConverter.ConvertToList(dataTable, row => row["Username"].ToString());

            if (usernames.Count == 0)
            {
                Console.WriteLine($"There are no usernames starting with {startingLetters}");
            }
            else
            {
                Console.WriteLine($"Usernames starting with {startingLetters}");
                usernames.ForEach(Console.WriteLine);
            }
        }
    }
}
