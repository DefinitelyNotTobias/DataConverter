﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConverterApp.Models;

namespace ConverterApp.Converters
{
    public class DataConverter
    {
        public static T? ConvertToModel<T>(DataTable dataTable, Func<DataRow, T> converter)
        {
            if (dataTable.Rows.Count == 0)
            {
                return default(T);
            }

            DataRow row = dataTable.Rows[0];

            return converter(row);
        }

        public static List<T> ConvertToList<T>(DataTable dataTable, Func<DataRow, T?> converter)
        {
            List<T> res = new List<T>();

            foreach (DataRow row in dataTable.Rows)
            {
                T? value = converter(row);
                if (value != null)
                {
                    res.Add(value);
                }
            }

            return res;
        }
    }
}